<?php

echo file_get_contents("utf8index.html");

?>